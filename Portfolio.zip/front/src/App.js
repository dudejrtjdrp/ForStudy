import logo from './logo.svg';
import './App.css';
import React from "react";
import Example from "./Example";

function App() {
  return (
    <div>
      <Example />
    </div>
  );
}

export default App;
